export const navs = [
  {
    label: '首页',
    value: '/',
  },
  {
    label: '咨询',
    value: '/info',
  },
  {
    label: '标签',
    value: '/tag',
  },
];
