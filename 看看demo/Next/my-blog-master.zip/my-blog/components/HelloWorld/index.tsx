import styles from './index.module.scss';

const HelloWorld = () => {
  return <div className={styles.hello}>Hello World</div>;
};

export default HelloWorld;
